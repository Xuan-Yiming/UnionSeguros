create
    definer = admin@`%` procedure MODIFICAR_POLIZA(IN _id_poliza int, IN _fid_moneda int, IN _fid_metodo int,
                                                   IN _fid_vehiculo int, IN _fid_cliente int,
                                                   IN _precio_base decimal(10, 2), IN _fecha_vigencia_desde date,
                                                   IN _fecha_vigencia_fin date)
BEGIN
	UPDATE poliza SET fid_moneda = _fid_moneda, fid_metodo = _fid_metodo, fid_vehiculo = _fid_vehiculo, fid_cliente = _fid_cliente, 
						precio_base = _precio_base, fecha_vigencia_desde = _fecha_vigencia_desde, 
						fecha_vigencia_fin = _fecha_vigencia_fin
    WHERE id_poliza = _id_poliza;
END;

