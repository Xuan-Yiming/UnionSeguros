create
    definer = admin@`%` procedure ELIMINAR_METODO_DE_PAGO(IN _id_metodo int)
BEGIN
	UPDATE metodo_de_pago SET activo = 0 WHERE id_metodo = _id_metodo;
END;

