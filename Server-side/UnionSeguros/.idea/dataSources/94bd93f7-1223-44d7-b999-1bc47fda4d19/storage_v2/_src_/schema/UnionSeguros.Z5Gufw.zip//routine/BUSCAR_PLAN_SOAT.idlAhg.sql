create
    definer = admin@`%` procedure BUSCAR_PLAN_SOAT(IN valor_busqueda varchar(255))
BEGIN
	SELECT id_plan_soat,nombre_plan,cobertura,precio,activo FROM plan_soat 
    WHERE CONCAT(CAST(id_plan_soat AS CHAR), nombre_plan, CAST(cobertura AS CHAR), CAST(precio AS CHAR), CAST(activo AS CHAR)) 
    LIKE CONCAT('%', valor_busqueda, '%')
    ORDER BY nombre_plan ASC;
END;

