create
    definer = admin@`%` procedure ELIMINAR_TIPO_USO(IN _id_tipo_uso int)
BEGIN
	UPDATE tipo_uso SET activo = 0 WHERE id_tipo_uso = _id_tipo_uso;
END;

