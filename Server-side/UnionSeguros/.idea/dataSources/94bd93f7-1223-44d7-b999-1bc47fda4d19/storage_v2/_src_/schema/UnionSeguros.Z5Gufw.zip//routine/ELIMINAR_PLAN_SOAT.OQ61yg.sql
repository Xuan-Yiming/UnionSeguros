create
    definer = admin@`%` procedure ELIMINAR_PLAN_SOAT(IN _id_plan_soat int)
BEGIN
	UPDATE plan_soat SET activo = 0 WHERE id_plan_soat = _id_plan_soat;
END;

