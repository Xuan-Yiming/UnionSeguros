create
    definer = admin@`%` procedure MODIFICAR_METODO_DE_PAGO(IN _id_metodo int, IN _nombre_metodo varchar(100),
                                                           IN _nombre_titular varchar(100), IN _correo varchar(100),
                                                           IN _numero_tarjeta varchar(30), IN _cvv varchar(5),
                                                           IN _fecha_vencimiento date)
BEGIN
	UPDATE metodo_de_pago SET nombre_metodo = _nombre_metodo, numero_tarjeta = _numero_tarjeta, cvv = _cvv, 
								fecha_vencimiento = _fecha_vencimiento, nombre_titular = _nombre_titular, correo = _correo
    WHERE id_metodo = _id_metodo;
END;

