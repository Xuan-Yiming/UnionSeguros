create
    definer = admin@`%` procedure MODIFICAR_TIPO_VEHICULO(IN _id_tipo_vehiculo int, IN _nombre_tipo_vehiculo varchar(30))
BEGIN
	UPDATE tipo_vehiculo SET nombre_tipo_vehiculo = _nombre_tipo_vehiculo
    WHERE id_tipo_vehiculo = _id_tipo_vehiculo;
END;

