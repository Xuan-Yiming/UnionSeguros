create
    definer = admin@`%` procedure LISTAR_TIPO_VEHICULO()
BEGIN
	SELECT id_tipo_vehiculo, nombre_tipo_vehiculo FROM tipo_vehiculo WHERE activo = 1;
END;

