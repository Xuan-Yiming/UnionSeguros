create
    definer = admin@`%` procedure INSERTAR_METODO_DE_PAGO(OUT _id_metodo int, IN _nombre_metodo varchar(100),
                                                          IN _nombre_titular varchar(100), IN _correo varchar(100),
                                                          IN _numero_tarjeta varchar(30), IN _cvv varchar(5),
                                                          IN _fecha_vencimiento date)
BEGIN
	SET _id_metodo = @@last_insert_id;
	INSERT INTO metodo_de_pago(id_metodo,nombre_metodo,nombre_titular,correo,numero_tarjeta,cvv,fecha_vencimiento,activo) 
						VALUES(_id_metodo,_nombre_metodo,_nombre_titular,_correo,_numero_tarjeta,_cvv,_fecha_vencimiento,1);
END;

