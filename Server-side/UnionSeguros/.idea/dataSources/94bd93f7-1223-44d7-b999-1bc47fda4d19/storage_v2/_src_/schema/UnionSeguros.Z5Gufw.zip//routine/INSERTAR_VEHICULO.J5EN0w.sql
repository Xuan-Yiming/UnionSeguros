create
    definer = admin@`%` procedure INSERTAR_VEHICULO(OUT _id_vehiculo int, IN _fid_tipo_uso int, IN _fid_modelo int,
                                                    IN _fid_persona int, IN _anho_fabricacion date,
                                                    IN _numero_asientos int, IN _placa varchar(15),
                                                    IN _serie varchar(15))
BEGIN
	SET _id_vehiculo = @@last_insert_id;
	INSERT INTO vehiculo(id_vehiculo,fid_tipo_uso,fid_modelo,fid_persona,anho_fabricacion,numero_asientos,placa,serie,activo) 
				VALUES(_id_vehiculo,_fid_tipo_uso,_fid_modelo,_fid_persona,_anho_fabricacion,_numero_asientos,_placa,_serie,1);
END;

