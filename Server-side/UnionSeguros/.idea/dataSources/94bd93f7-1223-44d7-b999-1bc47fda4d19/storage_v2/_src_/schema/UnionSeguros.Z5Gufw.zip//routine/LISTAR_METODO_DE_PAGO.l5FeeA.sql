create
    definer = admin@`%` procedure LISTAR_METODO_DE_PAGO()
BEGIN
	SELECT id_metodo,nombre_metodo,nombre_titular,correo,numero_tarjeta,cvv,fecha_vencimiento FROM metodo_de_pago WHERE activo = 1;
END;

