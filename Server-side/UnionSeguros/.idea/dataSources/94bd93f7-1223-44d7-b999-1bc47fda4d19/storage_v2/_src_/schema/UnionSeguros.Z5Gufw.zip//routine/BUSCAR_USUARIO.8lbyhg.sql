create
    definer = admin@`%` procedure BUSCAR_USUARIO(IN valor_busqueda varchar(255))
BEGIN
	SELECT id_persona,email,contrasena,fecha_creacion,activo FROM usuario 
    WHERE CONCAT(/*CAST(id_persona AS CHAR), */email,contrasena,/*CAST(fecha_creacion AS CHAR), */CAST(activo AS CHAR)) 
    LIKE CONCAT('%', valor_busqueda, '%')
    ORDER BY nombre_plan ASC;
END;

