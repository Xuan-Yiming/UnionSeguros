create
    definer = admin@`%` procedure MODIFICAR_MODELO(IN _id_modelo int, IN _modelo varchar(30),
                                                   IN _fid_marca_vehiculo int, IN _fid_tipo_vehiculo int)
BEGIN
	UPDATE modelo SET modelo = _modelo, fid_marca_vehiculo = _fid_marca_vehiculo, fid_tipo_vehiculo = _fid_tipo_vehiculo
    WHERE id_modelo = _id_modelo;
END;

