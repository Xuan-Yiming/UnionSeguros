create
    definer = admin@`%` procedure INSERTAR_MODELO(OUT _id_modelo int, IN _modelo varchar(30),
                                                  IN _fid_marca_vehiculo int, IN _fid_tipo_vehiculo int)
BEGIN
	SET _id_modelo = @@last_insert_id;
	INSERT INTO modelo(id_modelo,modelo,fid_marca_vehiculo,fid_tipo_vehiculo,activo) 
				VALUES(id_modelo,_modelo,_fid_marca_vehiculo,_fid_tipo_vehiculo,1);
END;

