create
    definer = admin@`%` procedure LISTAR_MODELO()
BEGIN
	SELECT id_modelo, fid_marca_vehiculo, fid_tipo_vehiculo, modelo FROM modelo WHERE activo = 1;
END;

