create
    definer = admin@`%` procedure ELIMINAR_BOLETA_DE_VENTA(IN _id_boleta int)
BEGIN
	UPDATE boleta_de_venta SET activo = 0 WHERE id_boleta = _id_boleta;
END;

