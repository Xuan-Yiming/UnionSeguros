create
    definer = admin@`%` procedure INSERTAR_PLAN_SOAT(OUT _id_plan_soat int, IN _nombre_plan varchar(30),
                                                     IN _cobertura decimal(10, 2), IN _precio decimal(10, 2))
BEGIN
	SET _id_plan_soat = @@last_insert_id;
	INSERT INTO plan_soat(id_plan_soat,cobertura,precio,nombre_plan,activo) VALUES(_id_plan_soat,_cobertura,_precio,_nombre_plan,1);
END;

