create
    definer = admin@`%` procedure LISTAR_VEHICULO()
BEGIN
	SELECT id_vehiculo,fid_tipo_uso,fid_modelo,fid_persona,anho_fabricacion,numero_asientos,placa,serie FROM vehiculo WHERE activo = 1;
END;

