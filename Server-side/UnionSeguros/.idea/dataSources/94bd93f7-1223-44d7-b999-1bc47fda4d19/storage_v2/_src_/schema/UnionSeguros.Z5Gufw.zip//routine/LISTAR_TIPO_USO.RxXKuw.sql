create
    definer = admin@`%` procedure LISTAR_TIPO_USO()
BEGIN
	SELECT id_tipo_uso, nombre_tipo_uso FROM tipo_uso WHERE activo = 1;
END;

