create
    definer = admin@`%` procedure MODIFICAR_TIPO_USO(IN _id_tipo_uso int, IN _nombre_tipo_uso varchar(30))
BEGIN
	UPDATE tipo_uso SET nombre_tipo_uso = _nombre_tipo_uso
    WHERE id_tipo_uso = _id_tipo_uso;
END;

