create
    definer = admin@`%` procedure MODIFICAR_BOLETA_DE_VENTA(IN _id_boleta int, IN _fid_soat int, IN _fecha_emision date,
                                                            IN _monto decimal(10, 2))
BEGIN
	UPDATE boleta_de_venta SET fecha_emision = _fecha_emision, monto = _monto, fid_soat = _fid_soat
    WHERE id_boleta = _id_boleta;
END;

