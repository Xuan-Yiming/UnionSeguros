create
    definer = admin@`%` procedure LISTAR_PLAN_SOAT()
BEGIN
	SELECT id_plan_soat,nombre_plan,cobertura,precio FROM plan_soat WHERE activo = 1;
END;

